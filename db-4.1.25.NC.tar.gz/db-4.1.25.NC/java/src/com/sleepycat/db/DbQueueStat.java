/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbQueueStat
{
    public int qs_magic;
    public int qs_version;
    public int qs_metaflags;
    public int qs_nkeys;
    public int qs_ndata;
    public int qs_pagesize;
    public int qs_extentsize;
    public int qs_pages;
    public int qs_re_len;
    public int qs_re_pad;
    public int qs_pgfree;
    public int qs_first_recno;
    public int qs_cur_recno;
}
// end of DbQueueStat.java
