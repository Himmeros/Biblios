/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbHashStat
{
    public int hash_magic;
    public int hash_version;
    public int hash_metaflags;
    public int hash_nkeys;
    public int hash_ndata;
    public int hash_pagesize;
    public int hash_ffactor;
    public int hash_buckets;
    public int hash_free;
    public int hash_bfree;
    public int hash_bigpages;
    public int hash_big_bfree;
    public int hash_overflows;
    public int hash_ovfl_free;
    public int hash_dup;
    public int hash_dup_free;
}
// end of DbHashStat.java
