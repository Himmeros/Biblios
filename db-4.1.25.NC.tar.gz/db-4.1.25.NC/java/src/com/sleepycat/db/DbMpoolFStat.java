/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbMpoolFStat
{
    public String file_name;
    public int st_pagesize;
    public int st_map;
    public int st_cache_hit;
    public int st_cache_miss;
    public int st_page_create;
    public int st_page_in;
    public int st_page_out;
}
// end of DbMpoolFStat.java
