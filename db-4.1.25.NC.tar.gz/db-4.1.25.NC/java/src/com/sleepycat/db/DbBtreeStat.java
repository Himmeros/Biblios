/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbBtreeStat
{
    public int bt_magic;
    public int bt_version;
    public int bt_metaflags;
    public int bt_nkeys;
    public int bt_ndata;
    public int bt_pagesize;
    public int bt_maxkey;
    public int bt_minkey;
    public int bt_re_len;
    public int bt_re_pad;
    public int bt_levels;
    public int bt_int_pg;
    public int bt_leaf_pg;
    public int bt_dup_pg;
    public int bt_over_pg;
    public int bt_free;
    public int bt_int_pgfree;
    public int bt_leaf_pgfree;
    public int bt_dup_pgfree;
    public int bt_over_pgfree;
}
// end of DbBtreeStat.java
