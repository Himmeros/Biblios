/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbLockStat
{
    public int st_id;
    public int st_cur_maxid;
    public int st_maxlocks;
    public int st_maxlockers;
    public int st_maxobjects;
    public int st_nmodes;
    public int st_nlocks;
    public int st_maxnlocks;
    public int st_nlockers;
    public int st_maxnlockers;
    public int st_nobjects;
    public int st_maxnobjects;
    public int st_nconflicts;
    public int st_nrequests;
    public int st_nreleases;
    public int st_nnowaits;
    public int st_ndeadlocks;
    public int st_locktimeout;
    public int st_nlocktimeouts;
    public int st_txntimeout;
    public int st_ntxntimeouts;
    public int st_region_wait;
    public int st_region_nowait;
    public int st_regsize;
}
// end of DbLockStat.java
