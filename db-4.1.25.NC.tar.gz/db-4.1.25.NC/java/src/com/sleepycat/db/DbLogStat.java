/* DO NOT EDIT: automatically built by dist/s_java. */

package com.sleepycat.db;

public class DbLogStat
{
    public int st_magic;
    public int st_version;
    public int st_mode;
    public int st_lg_bsize;
    public int st_lg_size;
    public int st_w_bytes;
    public int st_w_mbytes;
    public int st_wc_bytes;
    public int st_wc_mbytes;
    public int st_wcount;
    public int st_wcount_fill;
    public int st_scount;
    public int st_region_wait;
    public int st_region_nowait;
    public int st_cur_file;
    public int st_cur_offset;
    public int st_disk_file;
    public int st_disk_offset;
    public int st_regsize;
    public int st_maxcommitperflush;
    public int st_mincommitperflush;
}
// end of DbLogStat.java
