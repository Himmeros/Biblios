/* Do not edit: automatically built by gen_rec.awk. */

#ifndef	ex_apprec_AUTO_H
#define	ex_apprec_AUTO_H
#define	DB_ex_apprec_mkdir	10000
typedef struct _ex_apprec_mkdir_args {
	u_int32_t type;
	DB_TXN *txnid;
	DB_LSN prev_lsn;
	DBT	dirname;
} ex_apprec_mkdir_args;

#endif
