$self->{LIBS} = [ "@{$self->{LIBS}} -lpthreads" ];
