/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2001-2002
 *	Sleepycat Software.  All rights reserved.
 *
 * $Id: fop.h,v 11.3 2002/03/27 04:34:54 bostic Exp $
 */

#ifndef	_FOP_H_
#define	_FOP_H_

#include "dbinc_auto/fileops_auto.h"
#include "dbinc_auto/fileops_ext.h"

#endif /* !_FOP_H_ */
